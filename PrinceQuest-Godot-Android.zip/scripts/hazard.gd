extends Area2D

var hazard_width := 180.0

func setup(width: float) -> void:
    hazard_width = width
    collision_layer = 16
    collision_mask = 2
    var shape := RectangleShape2D.new()
    shape.size = Vector2(hazard_width, 36)
    var collision := CollisionShape2D.new()
    collision.shape = shape
    collision.position.y = 8
    add_child(collision)
    body_entered.connect(_on_body_entered)
    queue_redraw()

func _on_body_entered(body: Node) -> void:
    if body.has_method("hazard_hit"):
        body.hazard_hit()

func _draw() -> void:
    var count := maxi(1, int(hazard_width / 30.0))
    var start_x := -hazard_width * 0.5
    var step := hazard_width / float(count)
    for i in range(count):
        var x := start_x + i * step
        var pts := PackedVector2Array([Vector2(x,18), Vector2(x + step * 0.5,-24), Vector2(x + step,18)])
        draw_colored_polygon(pts, Color("#d8e0e8"))
        draw_polyline(PackedVector2Array([pts[0],pts[1],pts[2]]), Color("#68788a"), 2.0)
