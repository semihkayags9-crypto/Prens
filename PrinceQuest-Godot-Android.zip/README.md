# Prince Quest v0.3 - Gameplay Fix

Godot 4 tabanlı yatay mobil platform oyunu prototipi.

## Bu sürümde değişenler
- 1280x720 zorunlu yatay oyun düzeni
- 188 px yön ve 214 px zıplama butonu
- 14.500 px genişliğinde kayan bölüm
- Kamera takibi ve procedural parallax arka plan
- İlk bölümde ana rota yeniden kuruldu: platform kenar boşlukları yaklaşık 70-110 px, dikey çıkışlar ~95 px altında
- Zıplama gücü ve yatay hız mobil kullanım için biraz artırıldı; pixel-perfect sıçrama gerekmiyor
- 4 ayrı SVG düşman: slime, mantar, goblin, beetle
- Tepeden basınca düşman yenme, yandan temas hasarı ve kısa dokunulmazlık
- Checkpoint tabanlı yeniden doğma
- Altın/elmas rotaları ve bölüm ilerleme çubuğu
- Android export için ETC2/ASTC etkin
- GitHub Actions APK workflow

## Kontroller
- Android: Sol altta büyük sol/sağ butonları, sağ altta büyük zıplama butonu
- PC test: A/D veya ok tuşları, Space/Up ile zıpla

## GitHub Actions
Kaynak dosyaları repoya açılmış halde yüklediğinde `.github/workflows/build-apk.yml` otomatik olarak debug APK üretir.

## v0.3 geçilebilirlik düzeltmesi
Üst rota 32 adet birbirine yakın basamak platformla yeniden tasarlandı. İlk platforma yerden çıkış ve platformdan platforma geçişler prensin gerçek zıplama eğrisinden daha düşük tutuldu.
