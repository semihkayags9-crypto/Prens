extends Node

const PlayerScript = preload("res://scripts/player.gd")
const PlatformScript = preload("res://scripts/platform.gd")
const EnemyScript = preload("res://scripts/enemy.gd")
const CollectibleScript = preload("res://scripts/collectible.gd")
const HazardScript = preload("res://scripts/hazard.gd")
const GoalScript = preload("res://scripts/goal.gd")
const BackgroundScript = preload("res://scripts/background.gd")
const JoystickScript = preload("res://scripts/joystick.gd")

var player
var bg
var coins := 0
var gems := 0
var score := 0
var hearts_label: Label
var coin_label: Label
var gem_label: Label
var score_label: Label
var progress_bar: ProgressBar
var game_running := false
const LEVEL_END := 14500.0

func _ready() -> void:
    randomize()
    _show_menu()

func _process(_delta: float) -> void:
    if game_running and player and bg and bg.has_method("set_camera_x"):
        bg.set_camera_x(player.global_position.x)
    if game_running and player and progress_bar:
        progress_bar.value = clampf(player.global_position.x / LEVEL_END * 100.0, 0.0, 100.0)

func _clear_all() -> void:
    for child in get_children():
        remove_child(child)
        child.queue_free()

func _show_menu() -> void:
    game_running = false
    _clear_all()

    var bg_img := TextureRect.new()
    bg_img.texture = load("res://assets/reference/concept_gameplay.png")
    bg_img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg_img.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    bg_img.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg_img)

    var shade := ColorRect.new()
    shade.color = Color(0.015, 0.04, 0.08, 0.42)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(shade)

    var title := Label.new()
    title.text = "PRINCE QUEST"
    title.position = Vector2(72, 72)
    title.add_theme_font_size_override("font_size", 60)
    title.add_theme_color_override("font_color", Color.WHITE)
    title.add_theme_color_override("font_shadow_color", Color(0,0,0,0.35))
    title.add_theme_constant_override("shadow_offset_x", 3)
    title.add_theme_constant_override("shadow_offset_y", 4)
    add_child(title)

    var subtitle := Label.new()
    subtitle.text = "Elmasları topla • Canavarları aş • Prensesi kurtar"
    subtitle.position = Vector2(76, 150)
    subtitle.add_theme_font_size_override("font_size", 24)
    subtitle.add_theme_color_override("font_color", Color("#fff3c7"))
    add_child(subtitle)

    var play := _make_ui_button("OYNA", Vector2(80, 520), Vector2(300, 96), 34)
    play.pressed.connect(_start_game)
    add_child(play)

func _start_game() -> void:
    game_running = true
    coins = 0
    gems = 0
    score = 0
    _clear_all()

    var bg_layer := CanvasLayer.new()
    bg_layer.layer = -10
    add_child(bg_layer)
    bg = BackgroundScript.new()
    bg_layer.add_child(bg)

    var world := Node2D.new()
    world.name = "World"
    add_child(world)

    _build_level(world)

    player = PlayerScript.new()
    player.position = Vector2(150, 525)
    player.respawn_position = player.position
    player.health_changed.connect(_on_health_changed)
    player.died.connect(_on_player_died)
    world.add_child(player)

    var camera := Camera2D.new()
    camera.position = Vector2(150, -55)
    camera.position_smoothing_enabled = true
    camera.position_smoothing_speed = 8.5
    camera.limit_left = 0
    camera.limit_right = int(LEVEL_END + 500)
    camera.limit_top = 0
    camera.limit_bottom = 720
    player.add_child(camera)
    camera.make_current()

    _create_hud()

func _build_level(world: Node2D) -> void:
    # Main ground route. All gaps are 80-115 px: comfortably below the player's safe jump range.
    var ground := [
        [Vector2(300, 635), Vector2(600, 110)],
        [Vector2(970, 625), Vector2(560, 100)],
        [Vector2(1640, 635), Vector2(580, 110)],
        [Vector2(2325, 620), Vector2(590, 100)],
        [Vector2(3025, 635), Vector2(610, 110)],
        [Vector2(3745, 620), Vector2(620, 100)],
        [Vector2(4475, 635), Vector2(630, 110)],
        [Vector2(5220, 620), Vector2(650, 100)],
        [Vector2(5980, 635), Vector2(660, 110)],
        [Vector2(6750, 620), Vector2(670, 100)],
        [Vector2(7530, 635), Vector2(680, 110)],
        [Vector2(8320, 620), Vector2(690, 100)],
        [Vector2(9120, 635), Vector2(700, 110)],
        [Vector2(9930, 620), Vector2(710, 100)],
        [Vector2(10750, 635), Vector2(720, 110)],
        [Vector2(11580, 620), Vector2(730, 100)],
        [Vector2(12420, 635), Vector2(740, 110)],
        [Vector2(13270, 620), Vector2(750, 100)],
        [Vector2(14120, 635), Vector2(950, 110)]
    ]
    for item in ground:
        _add_platform(world, item[0], item[1], false)

    # Optional upper route. These are raised enough to leave ~120-160 px of visual clearance beneath.
    # They are also one-way, so the prince can jump upward through them and land from above.
    var floats := [
        [Vector2(790, 420), Vector2(270, 46)],
        [Vector2(1450, 400), Vector2(300, 46)],
        [Vector2(2140, 430), Vector2(280, 46)],
        [Vector2(2870, 395), Vector2(300, 46)],
        [Vector2(3610, 425), Vector2(290, 46)],
        [Vector2(4380, 390), Vector2(310, 46)],
        [Vector2(5140, 425), Vector2(290, 46)],
        [Vector2(5910, 395), Vector2(310, 46)],
        [Vector2(6690, 430), Vector2(290, 46)],
        [Vector2(7480, 400), Vector2(310, 46)],
        [Vector2(8280, 425), Vector2(300, 46)],
        [Vector2(9090, 395), Vector2(315, 46)],
        [Vector2(9910, 430), Vector2(300, 46)],
        [Vector2(10740, 400), Vector2(315, 46)],
        [Vector2(11580, 425), Vector2(300, 46)],
        [Vector2(12430, 395), Vector2(315, 46)],
        [Vector2(13290, 425), Vector2(300, 46)]
    ]
    for item in floats:
        _add_platform(world, item[0], item[1], true)

    # Hazards occupy only the centers of selected gaps and never seal the route.
    for hz in [[635,80],[1300,85],[1980,80],[2670,85],[3380,80],[4110,85],[4860,80],[5620,85],[6390,80],[7170,85],[7960,80],[8760,85],[9570,80],[10390,85],[11220,80],[12060,85],[12910,80]]:
        _add_hazard(world, Vector2(hz[0], 690), hz[1])

    # Collectibles guide the safe line. Ground coins sit above head height, upper-route gems mark optional jumps.
    for x in range(330, 14200, 300):
        var wave := float((int(x / 300) % 3) - 1) * 18.0
        _add_collectible(world, Vector2(x, 505 + wave), "coin")

    for p in floats:
        var fp: Vector2 = p[0]
        _add_collectible(world, fp + Vector2(0, -72), "gem")

    # Enemies have breathing room and do not occupy every landing zone.
    var enemies := [
        [1040,"slime",820,1180], [1750,"mushroom",1500,1880],
        [2460,"goblin",2220,2660], [3200,"beetle",2990,3410],
        [3970,"slime",3740,4170], [4740,"mushroom",4500,4970],
        [5520,"goblin",5270,5750], [6300,"beetle",6050,6530],
        [7080,"slime",6840,7310], [7870,"mushroom",7620,8110],
        [8670,"goblin",8420,8910], [9470,"beetle",9210,9720],
        [10290,"slime",10020,10550], [11120,"mushroom",10850,11390],
        [11960,"goblin",11680,12240], [12820,"beetle",12520,13100],
        [13680,"slime",13380,14020]
    ]
    for e in enemies:
        _add_enemy(world, Vector2(e[0], 525), e[1], e[2], e[3])

    var goal := GoalScript.new()
    goal.position = Vector2(14370, 558)
    goal.reached.connect(_on_goal_reached)
    world.add_child(goal)

func _add_platform(parent: Node, pos: Vector2, platform_size: Vector2, one_way: bool = false) -> void:
    var platform := PlatformScript.new()
    platform.position = pos
    platform.setup(platform_size, one_way)
    parent.add_child(platform)

func _add_collectible(parent: Node, pos: Vector2, kind: String) -> void:
    var item := CollectibleScript.new()
    item.position = pos
    item.setup(kind, 1)
    item.picked.connect(_on_pickup)
    parent.add_child(item)

func _add_enemy(parent: Node, pos: Vector2, kind: String, left_x: float, right_x: float) -> void:
    var enemy := EnemyScript.new()
    enemy.position = pos
    enemy.setup(kind, left_x, right_x)
    parent.add_child(enemy)

func _add_hazard(parent: Node, pos: Vector2, width: float) -> void:
    var hazard := HazardScript.new()
    hazard.position = pos
    hazard.setup(width)
    parent.add_child(hazard)

func _create_hud() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 20
    layer.name = "HUD"
    add_child(layer)

    var panel := ColorRect.new()
    panel.position = Vector2(18, 16)
    panel.size = Vector2(770, 72)
    panel.color = Color(0.025, 0.08, 0.15, 0.78)
    layer.add_child(panel)

    hearts_label = Label.new()
    hearts_label.position = Vector2(42, 32)
    hearts_label.text = "♥ ♥ ♥"
    hearts_label.add_theme_font_size_override("font_size", 34)
    hearts_label.add_theme_color_override("font_color", Color("#ff4e5f"))
    layer.add_child(hearts_label)

    coin_label = Label.new()
    coin_label.position = Vector2(245, 38)
    coin_label.text = "ALTIN 0"
    coin_label.add_theme_font_size_override("font_size", 24)
    coin_label.add_theme_color_override("font_color", Color("#ffd54a"))
    layer.add_child(coin_label)

    gem_label = Label.new()
    gem_label.position = Vector2(410, 38)
    gem_label.text = "ELMAS 0"
    gem_label.add_theme_font_size_override("font_size", 24)
    gem_label.add_theme_color_override("font_color", Color("#d477ff"))
    layer.add_child(gem_label)

    score_label = Label.new()
    score_label.position = Vector2(585, 38)
    score_label.text = "PUAN 0"
    score_label.add_theme_font_size_override("font_size", 24)
    score_label.add_theme_color_override("font_color", Color.WHITE)
    layer.add_child(score_label)

    progress_bar = ProgressBar.new()
    progress_bar.position = Vector2(820, 31)
    progress_bar.size = Vector2(300, 34)
    progress_bar.min_value = 0
    progress_bar.max_value = 100
    progress_bar.value = 0
    progress_bar.show_percentage = false
    layer.add_child(progress_bar)

    # Analog joystick replaces the old left/right buttons.
    var joystick := JoystickScript.new()
    joystick.position = Vector2(26, 462)
    joystick.size = Vector2(230, 230)
    joystick.axis_changed.connect(func(value: float): if player: player.set_touch_axis(value))
    layer.add_child(joystick)

    # Slightly larger jump button.
    var jump_btn := _make_ui_button("▲", Vector2(1028, 470), Vector2(228, 228), 88)
    layer.add_child(jump_btn)
    jump_btn.button_down.connect(func(): if player: player.request_jump())

    var menu_btn := _make_ui_button("II", Vector2(1195, 20), Vector2(64, 64), 22)
    menu_btn.pressed.connect(_show_menu)
    layer.add_child(menu_btn)

func _make_ui_button(text_value: String, pos: Vector2, button_size: Vector2, font_size: int) -> Button:
    var button := Button.new()
    button.text = text_value
    button.position = pos
    button.size = button_size
    button.focus_mode = Control.FOCUS_NONE
    button.add_theme_font_size_override("font_size", font_size)
    button.add_theme_color_override("font_color", Color.WHITE)
    button.add_theme_color_override("font_pressed_color", Color.WHITE)

    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.02, 0.08, 0.15, 0.68)
    normal.border_color = Color(0.90, 0.96, 1.0, 0.92)
    normal.set_border_width_all(4)
    var radius := int(minf(button_size.x, button_size.y) * 0.5)
    normal.set_corner_radius_all(radius)
    normal.shadow_color = Color(0,0,0,0.28)
    normal.shadow_size = 11

    var pressed: StyleBoxFlat = normal.duplicate() as StyleBoxFlat
    pressed.bg_color = Color(0.10, 0.38, 0.72, 0.94)
    var hover: StyleBoxFlat = normal.duplicate() as StyleBoxFlat
    hover.bg_color = Color(0.07, 0.24, 0.43, 0.84)
    button.add_theme_stylebox_override("normal", normal)
    button.add_theme_stylebox_override("pressed", pressed)
    button.add_theme_stylebox_override("hover", hover)
    return button

func _on_pickup(kind: String, amount: int) -> void:
    if kind == "coin":
        coins += amount
        score += 100 * amount
    else:
        gems += amount
        score += 250 * amount
    _update_hud()

func _update_hud() -> void:
    if coin_label: coin_label.text = "ALTIN %d" % coins
    if gem_label: gem_label.text = "ELMAS %d" % gems
    if score_label: score_label.text = "PUAN %d" % score

func _on_health_changed(value: int) -> void:
    if hearts_label:
        var t := ""
        for i in range(3):
            t += "♥ " if i < value else "♡ "
        hearts_label.text = t.strip_edges()

func _on_player_died() -> void:
    game_running = false
    _show_result("OYUN BİTTİ", "Prens yenildi. Tekrar dene!", false)

func _on_goal_reached() -> void:
    if not game_running:
        return
    game_running = false
    _show_result("PRENSES KURTARILDI!", "Lunarya yeniden ışığa kavuştu.", true)

func _show_result(title_text: String, subtitle_text: String, won: bool) -> void:
    var layer := CanvasLayer.new()
    layer.layer = 50
    add_child(layer)

    var shade := ColorRect.new()
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.color = Color(0.01, 0.03, 0.07, 0.78)
    layer.add_child(shade)

    var title := Label.new()
    title.text = title_text
    title.position = Vector2(340 if won else 420, 220)
    title.add_theme_font_size_override("font_size", 54)
    title.add_theme_color_override("font_color", Color("#ffe26b") if won else Color("#ff7180"))
    layer.add_child(title)

    var sub := Label.new()
    sub.text = subtitle_text
    sub.position = Vector2(390, 300)
    sub.add_theme_font_size_override("font_size", 26)
    sub.add_theme_color_override("font_color", Color.WHITE)
    layer.add_child(sub)

    var again := _make_ui_button("TEKRAR OYNA", Vector2(465, 400), Vector2(350, 94), 30)
    again.pressed.connect(_start_game)
    layer.add_child(again)
