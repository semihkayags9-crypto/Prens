extends Control

var camera_x := 0.0

func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    queue_redraw()

func set_camera_x(value: float) -> void:
    camera_x = value
    queue_redraw()

func _draw() -> void:
    var s := size
    draw_rect(Rect2(Vector2.ZERO, s), Color("#55bdf7"))

    # sun
    draw_circle(Vector2(s.x * 0.78, 110), 72, Color(1.0, 0.92, 0.55, 0.28))

    # clouds, very slow parallax
    var cloud_shift := -fmod(camera_x * 0.05, s.x)
    for tile in range(-1, 3):
        var base := Vector2(cloud_shift + tile * s.x, 0)
        for p in [Vector2(160,135), Vector2(460,105), Vector2(820,165), Vector2(1110,120)]:
            for o in [Vector2(-44,10), Vector2(0,-8), Vector2(42,12), Vector2(14,18)]:
                draw_circle(base + p + o, 34, Color(1,1,1,0.78))

    # far mountains
    var far_shift := -fmod(camera_x * 0.11, s.x)
    for tile in range(-1, 3):
        var bx := far_shift + tile * s.x
        var mountains := PackedVector2Array([
            Vector2(bx,535), Vector2(bx+180,310), Vector2(bx+335,535),
            Vector2(bx+520,295), Vector2(bx+720,535), Vector2(bx+930,320),
            Vector2(bx+1120,535), Vector2(bx+1280,330), Vector2(bx+1280,720), Vector2(bx,720)
        ])
        draw_colored_polygon(mountains, Color("#7ca6bf"))

    # near hills
    var near_shift := -fmod(camera_x * 0.22, s.x)
    for tile in range(-1, 3):
        var bx2 := near_shift + tile * s.x
        var hills := PackedVector2Array([
            Vector2(bx2,585), Vector2(bx2+160,455), Vector2(bx2+340,565),
            Vector2(bx2+560,430), Vector2(bx2+760,575), Vector2(bx2+990,445),
            Vector2(bx2+1280,580), Vector2(bx2+1280,720), Vector2(bx2,720)
        ])
        draw_colored_polygon(hills, Color("#69ad69"))
