extends Control

var camera_x := 0.0
const BASE_TEX = preload("res://assets/backgrounds/kingdom.svg")

func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    queue_redraw()

func set_camera_x(value: float) -> void:
    camera_x = value
    queue_redraw()

func _draw() -> void:
    var s := size
    draw_texture_rect(BASE_TEX, Rect2(Vector2.ZERO, s), false)

    # Mid-distance tree line that moves subtly for depth.
    var mid_shift := -fmod(camera_x * 0.08, s.x + 180.0)
    for tile in range(-1, 3):
        var bx := mid_shift + tile * (s.x + 180.0)
        for tx in range(70, 1420, 115):
            var wobble := float((tx * 13) % 55)
            var base := Vector2(bx + tx, 610 - wobble * 0.32)
            draw_rect(Rect2(base + Vector2(-4, -4), Vector2(8, 48)), Color(0.25, 0.36, 0.26, 0.28))
            draw_circle(base + Vector2(0, -16), 24, Color(0.24, 0.49, 0.31, 0.31))
            draw_circle(base + Vector2(-14, -8), 18, Color(0.31, 0.59, 0.35, 0.26))
            draw_circle(base + Vector2(16, -7), 19, Color(0.35, 0.65, 0.38, 0.24))

    # Foreground atmospheric strip and occasional leaves, faster parallax.
    var near_shift := -fmod(camera_x * 0.22, s.x + 240.0)
    draw_rect(Rect2(0, 610, s.x, 110), Color(0.04, 0.18, 0.12, 0.05))
    for tile in range(-1, 3):
        var nx := near_shift + tile * (s.x + 240.0)
        for i in range(8):
            var p := Vector2(nx + 70 + i * 175, 665 + float((i * 17) % 35))
            draw_circle(p, 20, Color(0.08, 0.31, 0.19, 0.18))
            draw_circle(p + Vector2(18, -5), 15, Color(0.18, 0.48, 0.27, 0.17))
