extends Area2D

signal reached

func _ready() -> void:
    collision_layer = 0
    collision_mask = 2
    var shape := RectangleShape2D.new()
    shape.size = Vector2(150, 250)
    var collision := CollisionShape2D.new()
    collision.shape = shape
    collision.position = Vector2(0,-80)
    add_child(collision)
    body_entered.connect(_on_body_entered)
    queue_redraw()

func _on_body_entered(body: Node) -> void:
    if body.is_in_group("player"):
        reached.emit()

func _draw() -> void:
    # tower
    draw_rect(Rect2(-72,-260,144,260), Color("#8b8f9a"))
    draw_rect(Rect2(-64,-250,128,250), Color("#b7bbc3"))
    var roof := PackedVector2Array([Vector2(-86,-260), Vector2(0,-345), Vector2(86,-260)])
    draw_colored_polygon(roof, Color("#cf4d3d"))
    draw_rect(Rect2(-35,-155,70,92), Color("#3c4050"))
    # princess
    draw_circle(Vector2(0,-150), 20, Color("#ffd6bc"))
    draw_circle(Vector2(0,-168), 23, Color("#f5c542"))
    draw_circle(Vector2(0,-149), 18, Color("#ffd6bc"))
    draw_colored_polygon(PackedVector2Array([Vector2(-30,-126),Vector2(30,-126),Vector2(46,-62),Vector2(-46,-62)]), Color("#f083b6"))
    var crown := PackedVector2Array([Vector2(-16,-186),Vector2(-10,-204),Vector2(0,-190),Vector2(10,-204),Vector2(16,-186)])
    draw_polyline(crown, Color("#ffd12c"), 7.0)
    draw_circle(Vector2(-6,-150), 2.4, Color("#2d4e77"))
    draw_circle(Vector2(6,-150), 2.4, Color("#2d4e77"))
