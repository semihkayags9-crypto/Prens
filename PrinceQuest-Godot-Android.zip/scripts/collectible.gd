extends Area2D

signal picked(kind: String, amount: int)

var kind := "gem"
var amount := 1
var base_y := 0.0
var phase := 0.0

func setup(new_kind: String, new_amount: int = 1) -> void:
    kind = new_kind
    amount = new_amount
    collision_layer = 8
    collision_mask = 2
    var shape := CircleShape2D.new()
    shape.radius = 23.0
    var collision := CollisionShape2D.new()
    collision.shape = shape
    add_child(collision)
    body_entered.connect(_on_body_entered)
    phase = randf() * TAU
    base_y = position.y
    queue_redraw()

func _process(delta: float) -> void:
    phase += delta * 2.35
    position.y = base_y + sin(phase) * 6.0
    rotation = sin(phase * 0.62) * 0.06
    queue_redraw()

func _on_body_entered(body: Node) -> void:
    if body.is_in_group("player"):
        picked.emit(kind, amount)
        queue_free()

func _draw() -> void:
    var pulse := 0.5 + 0.5 * sin(phase * 1.7)
    if kind == "coin":
        draw_circle(Vector2(0, 5), 25, Color(0.98, 0.75, 0.16, 0.12 + pulse * 0.10))
        draw_circle(Vector2.ZERO, 21, Color("#f6a80e"))
        draw_circle(Vector2.ZERO, 17, Color("#ffd85c"))
        draw_arc(Vector2.ZERO, 16, 0.3, 2.6, 24, Color("#fff4a5"), 3.0)
        draw_circle(Vector2(0, 1), 8, Color("#e39a09"))
        var crown := PackedVector2Array([Vector2(-7,3), Vector2(-5,-5), Vector2(0,0), Vector2(5,-5), Vector2(7,3)])
        draw_polyline(crown, Color("#fff0a0"), 2.2)
    else:
        draw_circle(Vector2.ZERO, 31, Color(0.68, 0.22, 1.0, 0.10 + pulse * 0.12))
        var pts := PackedVector2Array([Vector2(0,-27), Vector2(20,-8), Vector2(14,20), Vector2(0,30), Vector2(-14,20), Vector2(-20,-8)])
        draw_colored_polygon(pts, Color("#9b2cf5"))
        var inner := PackedVector2Array([Vector2(0,-22), Vector2(13,-5), Vector2(8,15), Vector2(0,24), Vector2(-7,14), Vector2(-13,-5)])
        draw_colored_polygon(inner, Color("#d875ff"))
        draw_polyline(PackedVector2Array([pts[0],pts[1],pts[2],pts[3],pts[4],pts[5],pts[0]]), Color("#f5c7ff"), 3.0)
        draw_line(Vector2(-9,-9), Vector2(5,13), Color(1,1,1,0.65), 3.0)
        draw_circle(Vector2(-6,-12), 3.2, Color.WHITE)
