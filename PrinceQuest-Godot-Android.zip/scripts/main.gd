extends Node

const PlayerScript = preload("res://scripts/player.gd")
const PlatformScript = preload("res://scripts/platform.gd")
const EnemyScript = preload("res://scripts/enemy.gd")
const CollectibleScript = preload("res://scripts/collectible.gd")
const HazardScript = preload("res://scripts/hazard.gd")
const GoalScript = preload("res://scripts/goal.gd")
const BackgroundScript = preload("res://scripts/background.gd")

var player
var bg
var coins := 0
var gems := 0
var score := 0
var hearts_label: Label
var coin_label: Label
var gem_label: Label
var score_label: Label
var progress_bar: ProgressBar
var game_running := false
const LEVEL_END := 14500.0

func _ready() -> void:
    randomize()
    _show_menu()

func _process(_delta: float) -> void:
    if game_running and player and bg and bg.has_method("set_camera_x"):
        bg.set_camera_x(player.global_position.x)
    if game_running and player and progress_bar:
        progress_bar.value = clampf(player.global_position.x / LEVEL_END * 100.0, 0.0, 100.0)

func _clear_all() -> void:
    for child in get_children():
        remove_child(child)
        child.queue_free()

func _show_menu() -> void:
    game_running = false
    _clear_all()

    var bg_img := TextureRect.new()
    bg_img.texture = load("res://assets/reference/concept_gameplay.png")
    bg_img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg_img.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    bg_img.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg_img)

    var shade := ColorRect.new()
    shade.color = Color(0.02, 0.06, 0.13, 0.48)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(shade)

    var title := Label.new()
    title.text = "PRINCE QUEST"
    title.position = Vector2(72, 72)
    title.add_theme_font_size_override("font_size", 58)
    title.add_theme_color_override("font_color", Color.WHITE)
    add_child(title)

    var subtitle := Label.new()
    subtitle.text = "Elmasları topla • Canavarları aş • Prensesi kurtar"
    subtitle.position = Vector2(76, 145)
    subtitle.add_theme_font_size_override("font_size", 23)
    subtitle.add_theme_color_override("font_color", Color("#fff1c2"))
    add_child(subtitle)

    var play := _make_ui_button("OYNA", Vector2(80, 520), Vector2(300, 96), 34)
    play.pressed.connect(_start_game)
    add_child(play)

func _start_game() -> void:
    game_running = true
    coins = 0
    gems = 0
    score = 0
    _clear_all()

    var bg_layer := CanvasLayer.new()
    bg_layer.layer = -10
    add_child(bg_layer)
    bg = BackgroundScript.new()
    bg_layer.add_child(bg)

    var world := Node2D.new()
    world.name = "World"
    add_child(world)

    _build_level(world)

    player = PlayerScript.new()
    player.position = Vector2(150, 525)
    player.respawn_position = player.position
    player.health_changed.connect(_on_health_changed)
    player.died.connect(_on_player_died)
    world.add_child(player)

    var camera := Camera2D.new()
    camera.position = Vector2(120, -70)
    camera.position_smoothing_enabled = true
    camera.position_smoothing_speed = 8.0
    camera.limit_left = 0
    camera.limit_right = int(LEVEL_END + 500)
    camera.limit_top = 0
    camera.limit_bottom = 720
    player.add_child(camera)
    camera.make_current()

    _create_hud()

func _build_level(world: Node2D) -> void:
    # Ground chunks. Gaps are short enough for the player's jump arc.
    var ground := [
        [Vector2(300, 635), Vector2(600, 110)],
        [Vector2(980, 625), Vector2(560, 100)],
        [Vector2(1660, 635), Vector2(600, 110)],
        [Vector2(2380, 610), Vector2(650, 90)],
        [Vector2(3150, 635), Vector2(650, 110)],
        [Vector2(3920, 620), Vector2(650, 100)],
        [Vector2(4700, 635), Vector2(660, 110)],
        [Vector2(5510, 610), Vector2(700, 90)],
        [Vector2(6350, 635), Vector2(700, 110)],
        [Vector2(7200, 620), Vector2(700, 100)],
        [Vector2(8050, 635), Vector2(710, 110)],
        [Vector2(8910, 610), Vector2(720, 90)],
        [Vector2(9780, 635), Vector2(740, 110)],
        [Vector2(10680, 620), Vector2(760, 100)],
        [Vector2(11600, 635), Vector2(780, 110)],
        [Vector2(12550, 610), Vector2(820, 90)],
        [Vector2(13620, 635), Vector2(950, 110)]
    ]
    for item in ground:
        _add_platform(world, item[0], item[1])

    # Main upper route. Every jump is deliberately conservative for mobile play:
    # adjacent platform edge gaps are about 70-110 px and vertical rises stay below ~95 px.
    # With the player's jump arc this leaves a large safety margin instead of pixel-perfect jumps.
    var floats := [
        [Vector2(750, 510), Vector2(340, 44)],
        [Vector2(1180, 480), Vector2(340, 44)],
        [Vector2(1610, 500), Vector2(340, 44)],
        [Vector2(2040, 470), Vector2(340, 44)],
        [Vector2(2470, 500), Vector2(340, 44)],
        [Vector2(2900, 475), Vector2(340, 44)],
        [Vector2(3330, 510), Vector2(340, 44)],
        [Vector2(3760, 480), Vector2(340, 44)],
        [Vector2(4190, 505), Vector2(340, 44)],
        [Vector2(4620, 475), Vector2(340, 44)],
        [Vector2(5050, 500), Vector2(340, 44)],
        [Vector2(5480, 470), Vector2(340, 44)],
        [Vector2(5910, 505), Vector2(340, 44)],
        [Vector2(6340, 480), Vector2(340, 44)],
        [Vector2(6770, 505), Vector2(340, 44)],
        [Vector2(7200, 475), Vector2(340, 44)],
        [Vector2(7630, 500), Vector2(340, 44)],
        [Vector2(8060, 470), Vector2(340, 44)],
        [Vector2(8490, 505), Vector2(340, 44)],
        [Vector2(8920, 480), Vector2(340, 44)],
        [Vector2(9350, 500), Vector2(340, 44)],
        [Vector2(9780, 475), Vector2(340, 44)],
        [Vector2(10210, 505), Vector2(340, 44)],
        [Vector2(10640, 470), Vector2(340, 44)],
        [Vector2(11070, 500), Vector2(340, 44)],
        [Vector2(11500, 480), Vector2(340, 44)],
        [Vector2(11930, 505), Vector2(340, 44)],
        [Vector2(12360, 475), Vector2(340, 44)],
        [Vector2(12790, 500), Vector2(340, 44)],
        [Vector2(13220, 470), Vector2(340, 44)],
        [Vector2(13650, 500), Vector2(340, 44)],
        [Vector2(14020, 485), Vector2(300, 44)]
    ]
    for item in floats:
        _add_platform(world, item[0], item[1])

    # Hazards only in the center of gaps, leaving forgiving landing space.
    for hz in [[640,110],[1320,110],[2020,110],[2770,110],[3540,110],[4320,110],[5120,110],[5950,110],[6800,110],[7640,110],[8500,110],[9360,110],[10280,110],[11190,110],[12100,110]]:
        _add_hazard(world, Vector2(hz[0], 690), hz[1])

    # Collectibles form visible paths rather than random decoration.
    for x in range(350, 14100, 320):
        _add_collectible(world, Vector2(x, 520 - (int(x / 320) % 2) * 35), "coin")

    var gem_points := [
        Vector2(750, 430), Vector2(1610, 420), Vector2(2470, 420), Vector2(3330, 430),
        Vector2(4190, 425), Vector2(5050, 420), Vector2(5910, 425), Vector2(6770, 425),
        Vector2(7630, 420), Vector2(8490, 425), Vector2(9350, 420), Vector2(10210, 425),
        Vector2(11070, 420), Vector2(11930, 425), Vector2(12790, 420), Vector2(13650, 420)
    ]
    for gp in gem_points:
        _add_collectible(world, gp, "gem")

    # Enemy encounters alternate types and never block every route.
    var enemies := [
        [1000,"slime",820,1160], [1700,"mushroom",1500,1830],
        [2450,"goblin",2220,2620], [3200,"beetle",2980,3380],
        [3980,"slime",3750,4150], [4780,"mushroom",4510,5000],
        [5580,"goblin",5320,5750], [6430,"beetle",6180,6600],
        [7300,"slime",7040,7480], [8120,"mushroom",7880,8300],
        [9000,"goblin",8730,9200], [9880,"beetle",9600,10100],
        [10780,"slime",10490,11020], [11710,"mushroom",11370,11980],
        [12630,"goblin",12300,12940], [13650,"beetle",13280,14000]
    ]
    for e in enemies:
        _add_enemy(world, Vector2(e[0], 530), e[1], e[2], e[3])

    var goal := GoalScript.new()
    goal.position = Vector2(14350, 555)
    goal.reached.connect(_on_goal_reached)
    world.add_child(goal)

func _add_platform(parent: Node, pos: Vector2, platform_size: Vector2) -> void:
    var platform := PlatformScript.new()
    platform.position = pos
    platform.setup(platform_size)
    parent.add_child(platform)

func _add_collectible(parent: Node, pos: Vector2, kind: String) -> void:
    var item := CollectibleScript.new()
    item.position = pos
    item.setup(kind, 1)
    item.picked.connect(_on_pickup)
    parent.add_child(item)

func _add_enemy(parent: Node, pos: Vector2, kind: String, left_x: float, right_x: float) -> void:
    var enemy := EnemyScript.new()
    enemy.position = pos
    enemy.setup(kind, left_x, right_x)
    parent.add_child(enemy)

func _add_hazard(parent: Node, pos: Vector2, width: float) -> void:
    var hazard := HazardScript.new()
    hazard.position = pos
    hazard.setup(width)
    parent.add_child(hazard)

func _create_hud() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 20
    layer.name = "HUD"
    add_child(layer)

    var panel := ColorRect.new()
    panel.position = Vector2(20, 16)
    panel.size = Vector2(760, 72)
    panel.color = Color(0.03, 0.09, 0.18, 0.78)
    layer.add_child(panel)

    hearts_label = Label.new()
    hearts_label.position = Vector2(42, 32)
    hearts_label.text = "♥ ♥ ♥"
    hearts_label.add_theme_font_size_override("font_size", 34)
    hearts_label.add_theme_color_override("font_color", Color("#ff4e5f"))
    layer.add_child(hearts_label)

    coin_label = Label.new()
    coin_label.position = Vector2(245, 38)
    coin_label.text = "ALTIN 0"
    coin_label.add_theme_font_size_override("font_size", 24)
    coin_label.add_theme_color_override("font_color", Color("#ffd54a"))
    layer.add_child(coin_label)

    gem_label = Label.new()
    gem_label.position = Vector2(410, 38)
    gem_label.text = "ELMAS 0"
    gem_label.add_theme_font_size_override("font_size", 24)
    gem_label.add_theme_color_override("font_color", Color("#d477ff"))
    layer.add_child(gem_label)

    score_label = Label.new()
    score_label.position = Vector2(585, 38)
    score_label.text = "PUAN 0"
    score_label.add_theme_font_size_override("font_size", 24)
    score_label.add_theme_color_override("font_color", Color.WHITE)
    layer.add_child(score_label)

    progress_bar = ProgressBar.new()
    progress_bar.position = Vector2(820, 31)
    progress_bar.size = Vector2(300, 34)
    progress_bar.min_value = 0
    progress_bar.max_value = 100
    progress_bar.value = 0
    progress_bar.show_percentage = false
    layer.add_child(progress_bar)

    # Large thumb-friendly controls.
    var left_btn := _make_ui_button("◀", Vector2(24, 502), Vector2(188, 188), 72)
    var right_btn := _make_ui_button("▶", Vector2(226, 502), Vector2(188, 188), 72)
    var jump_btn := _make_ui_button("▲", Vector2(1048, 480), Vector2(214, 214), 84)
    layer.add_child(left_btn)
    layer.add_child(right_btn)
    layer.add_child(jump_btn)

    left_btn.button_down.connect(func(): if player: player.set_touch_left(true))
    left_btn.button_up.connect(func(): if player: player.set_touch_left(false))
    right_btn.button_down.connect(func(): if player: player.set_touch_right(true))
    right_btn.button_up.connect(func(): if player: player.set_touch_right(false))
    jump_btn.button_down.connect(func(): if player: player.request_jump())

    var menu_btn := _make_ui_button("II", Vector2(1195, 20), Vector2(64, 64), 22)
    menu_btn.pressed.connect(_show_menu)
    layer.add_child(menu_btn)

func _make_ui_button(text_value: String, pos: Vector2, button_size: Vector2, font_size: int) -> Button:
    var button := Button.new()
    button.text = text_value
    button.position = pos
    button.size = button_size
    button.focus_mode = Control.FOCUS_NONE
    button.add_theme_font_size_override("font_size", font_size)
    button.add_theme_color_override("font_color", Color.WHITE)
    button.add_theme_color_override("font_pressed_color", Color.WHITE)

    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.02, 0.08, 0.15, 0.64)
    normal.border_color = Color(0.90, 0.96, 1.0, 0.92)
    normal.set_border_width_all(4)
    var radius := int(minf(button_size.x, button_size.y) * 0.5)
    normal.set_corner_radius_all(radius)
    normal.shadow_color = Color(0,0,0,0.25)
    normal.shadow_size = 10

    var pressed: StyleBoxFlat = normal.duplicate() as StyleBoxFlat
    pressed.bg_color = Color(0.10, 0.38, 0.72, 0.92)
    var hover: StyleBoxFlat = normal.duplicate() as StyleBoxFlat
    hover.bg_color = Color(0.07, 0.24, 0.43, 0.84)
    button.add_theme_stylebox_override("normal", normal)
    button.add_theme_stylebox_override("pressed", pressed)
    button.add_theme_stylebox_override("hover", hover)
    return button

func _on_pickup(kind: String, amount: int) -> void:
    if kind == "coin":
        coins += amount
        score += 100 * amount
    else:
        gems += amount
        score += 250 * amount
    _update_hud()

func _update_hud() -> void:
    if coin_label: coin_label.text = "ALTIN %d" % coins
    if gem_label: gem_label.text = "ELMAS %d" % gems
    if score_label: score_label.text = "PUAN %d" % score

func _on_health_changed(value: int) -> void:
    if hearts_label:
        var t := ""
        for i in range(3):
            t += "♥ " if i < value else "♡ "
        hearts_label.text = t.strip_edges()

func _on_player_died() -> void:
    game_running = false
    _show_result("OYUN BİTTİ", "Prens yenildi. Tekrar dene!", false)

func _on_goal_reached() -> void:
    if not game_running:
        return
    game_running = false
    score += gems * 100 + coins * 25
    _show_result("PRENSES KURTARILDI!", "Elmas: %d • Altın: %d • Puan: %d" % [gems, coins, score], true)

func _show_result(title_text: String, detail: String, won: bool) -> void:
    if player:
        player.set_physics_process(false)
    var layer := CanvasLayer.new()
    layer.layer = 50
    add_child(layer)
    var dim := ColorRect.new()
    dim.color = Color(0.01,0.03,0.08,0.74)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(dim)

    var panel := ColorRect.new()
    panel.position = Vector2(250, 190)
    panel.size = Vector2(780, 330)
    panel.color = Color("#13243b")
    layer.add_child(panel)

    var title := Label.new()
    title.text = title_text
    title.position = Vector2(300, 240)
    title.size = Vector2(680, 70)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 44)
    title.add_theme_color_override("font_color", Color("#ffd85e") if won else Color("#ff6f73"))
    layer.add_child(title)

    var label := Label.new()
    label.text = detail
    label.position = Vector2(300, 330)
    label.size = Vector2(680, 50)
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.add_theme_font_size_override("font_size", 21)
    label.add_theme_color_override("font_color", Color.WHITE)
    layer.add_child(label)

    var replay := _make_ui_button("TEKRAR OYNA", Vector2(365, 420), Vector2(250, 72), 23)
    replay.pressed.connect(_start_game)
    layer.add_child(replay)
    var menu := _make_ui_button("MENÜ", Vector2(665, 420), Vector2(250, 72), 23)
    menu.pressed.connect(_show_menu)
    layer.add_child(menu)
