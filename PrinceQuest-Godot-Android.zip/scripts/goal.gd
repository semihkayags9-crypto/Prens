extends Area2D

signal reached

func _ready() -> void:
    collision_layer = 0
    collision_mask = 2
    var shape := RectangleShape2D.new()
    shape.size = Vector2(170, 270)
    var collision := CollisionShape2D.new()
    collision.shape = shape
    collision.position = Vector2(0,-92)
    add_child(collision)
    body_entered.connect(_on_body_entered)

    var sprite := Sprite2D.new()
    sprite.texture = load("res://assets/world/goal_castle.svg")
    sprite.scale = Vector2(0.76, 0.76)
    sprite.position = Vector2(0, -170)
    add_child(sprite)

func _on_body_entered(body: Node) -> void:
    if body.is_in_group("player"):
        reached.emit()
