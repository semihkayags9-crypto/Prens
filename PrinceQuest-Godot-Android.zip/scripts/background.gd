extends Control

func _ready() -> void:
    position = Vector2.ZERO
    size = get_viewport_rect().size
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    queue_redraw()

func _draw() -> void:
    var s := size
    draw_rect(Rect2(Vector2.ZERO, s), Color("#55bdf7"))
    # distant sun glow
    draw_circle(Vector2(s.x * 0.78, 115), 72, Color(1.0, 0.92, 0.55, 0.35))
    # clouds
    var cloud_points = [Vector2(170,135), Vector2(460,105), Vector2(820,170), Vector2(1110,115)]
    for p in cloud_points:
        for o in [Vector2(-45,10), Vector2(0,-8), Vector2(42,12), Vector2(14,18)]:
            draw_circle(p + o, 34, Color(1,1,1,0.82))
    # distant mountains
    var mountains := PackedVector2Array([
        Vector2(0,520), Vector2(170,315), Vector2(315,520), Vector2(505,300),
        Vector2(690,520), Vector2(890,330), Vector2(1060,520), Vector2(1240,325),
        Vector2(1280,520)
    ])
    draw_colored_polygon(mountains, Color("#7fa9c4"))
    var hills := PackedVector2Array([
        Vector2(0,560), Vector2(180,450), Vector2(360,545), Vector2(565,435),
        Vector2(760,555), Vector2(980,445), Vector2(1280,560), Vector2(1280,720), Vector2(0,720)
    ])
    draw_colored_polygon(hills, Color("#70b56e"))
