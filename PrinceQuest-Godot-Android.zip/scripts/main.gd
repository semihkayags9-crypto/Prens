extends Node

const PlayerScript = preload("res://scripts/player.gd")
const PlatformScript = preload("res://scripts/platform.gd")
const EnemyScript = preload("res://scripts/enemy.gd")
const CollectibleScript = preload("res://scripts/collectible.gd")
const HazardScript = preload("res://scripts/hazard.gd")
const GoalScript = preload("res://scripts/goal.gd")
const BackgroundScript = preload("res://scripts/background.gd")

var player
var coins := 0
var gems := 0
var score := 0
var hearts_label: Label
var coin_label: Label
var gem_label: Label
var score_label: Label
var game_running := false

func _ready() -> void:
    randomize()
    _show_menu()

func _clear_all() -> void:
    for child in get_children():
        remove_child(child)
        child.queue_free()

func _show_menu() -> void:
    game_running = false
    _clear_all()

    var bg := TextureRect.new()
    bg.texture = load("res://assets/reference/concept_gameplay.png")
    bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)

    var shade := ColorRect.new()
    shade.color = Color(0.02, 0.06, 0.13, 0.42)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(shade)

    var title := Label.new()
    title.text = "PRINCE QUEST"
    title.position = Vector2(70, 70)
    title.add_theme_font_size_override("font_size", 54)
    title.add_theme_color_override("font_color", Color.WHITE)
    add_child(title)

    var subtitle := Label.new()
    subtitle.text = "Elmasları topla. Canavarları aş. Prensesi kurtar."
    subtitle.position = Vector2(74, 140)
    subtitle.add_theme_font_size_override("font_size", 24)
    subtitle.add_theme_color_override("font_color", Color("#fff1c2"))
    add_child(subtitle)

    var play := _make_ui_button("OYNA", Vector2(78, 535), Vector2(260, 88), 32)
    play.pressed.connect(_start_game)
    add_child(play)

    var hint := Label.new()
    hint.text = "PC: A/D veya oklar + Space   •   Android: ekrandaki butonlar"
    hint.position = Vector2(78, 640)
    hint.add_theme_font_size_override("font_size", 18)
    hint.add_theme_color_override("font_color", Color(1,1,1,0.9))
    add_child(hint)

func _start_game() -> void:
    game_running = true
    coins = 0
    gems = 0
    score = 0
    _clear_all()

    var bg_layer := CanvasLayer.new()
    bg_layer.layer = -10
    add_child(bg_layer)
    var bg := BackgroundScript.new()
    bg_layer.add_child(bg)

    var world := Node2D.new()
    world.name = "World"
    add_child(world)

    # Main path
    _add_platform(world, Vector2(260, 640), Vector2(520, 110))
    _add_platform(world, Vector2(850, 620), Vector2(430, 90))
    _add_platform(world, Vector2(1370, 580), Vector2(360, 90))
    _add_platform(world, Vector2(1840, 630), Vector2(420, 100))
    _add_platform(world, Vector2(2370, 570), Vector2(420, 90))
    _add_platform(world, Vector2(2860, 640), Vector2(400, 110))
    _add_platform(world, Vector2(3360, 590), Vector2(430, 90))
    _add_platform(world, Vector2(3890, 640), Vector2(500, 110))
    _add_platform(world, Vector2(4550, 610), Vector2(520, 100))

    # Floating platforms
    _add_platform(world, Vector2(760, 420), Vector2(230, 50))
    _add_platform(world, Vector2(1220, 370), Vector2(250, 50))
    _add_platform(world, Vector2(2130, 385), Vector2(250, 50))
    _add_platform(world, Vector2(3150, 360), Vector2(260, 50))
    _add_platform(world, Vector2(3720, 420), Vector2(230, 50))

    # Spikes in the gaps
    _add_hazard(world, Vector2(590, 685), 130)
    _add_hazard(world, Vector2(1100, 685), 120)
    _add_hazard(world, Vector2(1600, 685), 120)
    _add_hazard(world, Vector2(2120, 685), 120)
    _add_hazard(world, Vector2(2620, 685), 120)
    _add_hazard(world, Vector2(3110, 685), 120)
    _add_hazard(world, Vector2(3640, 685), 120)
    _add_hazard(world, Vector2(4200, 685), 130)

    player = PlayerScript.new()
    player.position = Vector2(160, 540)
    player.respawn_position = player.position
    player.health_changed.connect(_on_health_changed)
    player.died.connect(_on_player_died)
    world.add_child(player)

    var camera := Camera2D.new()
    camera.position = Vector2(170, -70)
    camera.position_smoothing_enabled = true
    camera.position_smoothing_speed = 6.0
    camera.limit_left = 0
    camera.limit_right = 4950
    camera.limit_top = 0
    camera.limit_bottom = 720
    player.add_child(camera)
    camera.make_current()

    # Coins
    for p in [Vector2(420,500),Vector2(500,455),Vector2(580,420),Vector2(820,335),Vector2(900,335),Vector2(1280,300),Vector2(1360,300),Vector2(1760,520),Vector2(1840,485),Vector2(1920,520),Vector2(2320,470),Vector2(2400,430),Vector2(2480,470),Vector2(3300,490),Vector2(3380,455),Vector2(3460,490),Vector2(3860,525),Vector2(3940,485),Vector2(4020,525)]:
        _add_collectible(world, p, "coin")

    # Gems
    for p in [Vector2(700,300),Vector2(780,260),Vector2(860,300),Vector2(1460,450),Vector2(1540,410),Vector2(1620,450),Vector2(2100,290),Vector2(2180,250),Vector2(2260,290),Vector2(3060,270),Vector2(3140,230),Vector2(3220,270),Vector2(4380,450),Vector2(4460,410),Vector2(4540,450)]:
        _add_collectible(world, p, "gem")

    # Enemies
    _add_enemy(world, Vector2(910, 535), "slime", 760, 970)
    _add_enemy(world, Vector2(1350, 500), "goblin", 1240, 1480)
    _add_enemy(world, Vector2(1910, 545), "slime", 1720, 1980)
    _add_enemy(world, Vector2(2420, 490), "goblin", 2260, 2520)
    _add_enemy(world, Vector2(3310, 510), "slime", 3200, 3500)
    _add_enemy(world, Vector2(3950, 555), "goblin", 3740, 4080)

    var goal := GoalScript.new()
    goal.position = Vector2(4700, 560)
    goal.reached.connect(_on_goal_reached)
    world.add_child(goal)

    _create_hud()

func _add_platform(parent: Node, pos: Vector2, platform_size: Vector2) -> void:
    var platform := PlatformScript.new()
    platform.position = pos
    platform.setup(platform_size)
    parent.add_child(platform)

func _add_collectible(parent: Node, pos: Vector2, kind: String) -> void:
    var item := CollectibleScript.new()
    item.position = pos
    item.setup(kind, 1)
    item.picked.connect(_on_pickup)
    parent.add_child(item)

func _add_enemy(parent: Node, pos: Vector2, kind: String, left_x: float, right_x: float) -> void:
    var enemy := EnemyScript.new()
    enemy.position = pos
    enemy.setup(kind, left_x, right_x)
    parent.add_child(enemy)

func _add_hazard(parent: Node, pos: Vector2, width: float) -> void:
    var hazard := HazardScript.new()
    hazard.position = pos
    hazard.setup(width)
    parent.add_child(hazard)

func _create_hud() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 20
    layer.name = "HUD"
    add_child(layer)

    var panel := ColorRect.new()
    panel.position = Vector2(22, 18)
    panel.size = Vector2(680, 66)
    panel.color = Color(0.03, 0.09, 0.18, 0.72)
    layer.add_child(panel)

    hearts_label = Label.new()
    hearts_label.position = Vector2(44, 32)
    hearts_label.text = "♥ ♥ ♥"
    hearts_label.add_theme_font_size_override("font_size", 32)
    hearts_label.add_theme_color_override("font_color", Color("#ff4e5f"))
    layer.add_child(hearts_label)

    coin_label = Label.new()
    coin_label.position = Vector2(230, 37)
    coin_label.text = "ALTIN  0"
    coin_label.add_theme_font_size_override("font_size", 23)
    coin_label.add_theme_color_override("font_color", Color("#ffd54a"))
    layer.add_child(coin_label)

    gem_label = Label.new()
    gem_label.position = Vector2(390, 37)
    gem_label.text = "ELMAS  0"
    gem_label.add_theme_font_size_override("font_size", 23)
    gem_label.add_theme_color_override("font_color", Color("#d477ff"))
    layer.add_child(gem_label)

    score_label = Label.new()
    score_label.position = Vector2(555, 37)
    score_label.text = "PUAN  0"
    score_label.add_theme_font_size_override("font_size", 23)
    score_label.add_theme_color_override("font_color", Color.WHITE)
    layer.add_child(score_label)

    var left_btn := _make_ui_button("◀", Vector2(34, 566), Vector2(120, 120), 48)
    var right_btn := _make_ui_button("▶", Vector2(174, 566), Vector2(120, 120), 48)
    var jump_btn := _make_ui_button("▲", Vector2(1120, 566), Vector2(120, 120), 48)
    layer.add_child(left_btn)
    layer.add_child(right_btn)
    layer.add_child(jump_btn)

    left_btn.button_down.connect(_touch_left_down)
    left_btn.button_up.connect(_touch_left_up)
    right_btn.button_down.connect(_touch_right_down)
    right_btn.button_up.connect(_touch_right_up)
    jump_btn.button_down.connect(_touch_jump_down)

    var menu_btn := _make_ui_button("II", Vector2(1200, 24), Vector2(58, 58), 22)
    menu_btn.pressed.connect(_show_menu)
    layer.add_child(menu_btn)

func _touch_left_down() -> void:
    if player:
        player.set_touch_left(true)

func _touch_left_up() -> void:
    if player:
        player.set_touch_left(false)

func _touch_right_down() -> void:
    if player:
        player.set_touch_right(true)

func _touch_right_up() -> void:
    if player:
        player.set_touch_right(false)

func _touch_jump_down() -> void:
    if player:
        player.request_jump()

func _make_ui_button(text_value: String, pos: Vector2, button_size: Vector2, font_size: int) -> Button:
    var button := Button.new()
    button.text = text_value
    button.position = pos
    button.size = button_size
    button.focus_mode = Control.FOCUS_NONE
    button.add_theme_font_size_override("font_size", font_size)
    button.add_theme_color_override("font_color", Color.WHITE)
    button.add_theme_color_override("font_hover_color", Color.WHITE)
    button.add_theme_color_override("font_pressed_color", Color.WHITE)

    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.04, 0.12, 0.22, 0.72)
    normal.border_color = Color(0.85, 0.93, 1.0, 0.9)
    normal.border_width_left = 3
    normal.border_width_top = 3
    normal.border_width_right = 3
    normal.border_width_bottom = 3
    var radius := int(minf(button_size.x, button_size.y) * 0.5)
    normal.corner_radius_top_left = radius
    normal.corner_radius_top_right = radius
    normal.corner_radius_bottom_left = radius
    normal.corner_radius_bottom_right = radius
    var pressed: StyleBoxFlat = normal.duplicate() as StyleBoxFlat
    pressed.bg_color = Color(0.13, 0.38, 0.64, 0.9)
    var hover: StyleBoxFlat = normal.duplicate() as StyleBoxFlat
    hover.bg_color = Color(0.08, 0.24, 0.40, 0.85)
    button.add_theme_stylebox_override("normal", normal)
    button.add_theme_stylebox_override("pressed", pressed)
    button.add_theme_stylebox_override("hover", hover)
    return button

func _on_pickup(kind: String, amount: int) -> void:
    if kind == "coin":
        coins += amount
        score += 100 * amount
    else:
        gems += amount
        score += 250 * amount
    _update_hud()

func _update_hud() -> void:
    if coin_label:
        coin_label.text = "ALTIN  %d" % coins
    if gem_label:
        gem_label.text = "ELMAS  %d" % gems
    if score_label:
        score_label.text = "PUAN  %d" % score

func _on_health_changed(value: int) -> void:
    if hearts_label:
        var t := ""
        for i in range(3):
            t += "♥ " if i < value else "♡ "
        hearts_label.text = t.strip_edges()

func _on_player_died() -> void:
    game_running = false
    _show_result("OYUN BİTTİ", "Prens düştü. Bir kez daha dene!", false)

func _on_goal_reached() -> void:
    if not game_running:
        return
    game_running = false
    score += gems * 100 + coins * 25
    _show_result("PRENSES KURTARILDI!", "Bölüm tamamlandı • Elmas: %d • Altın: %d • Puan: %d" % [gems, coins, score], true)

func _show_result(title_text: String, detail: String, won: bool) -> void:
    if player:
        player.set_physics_process(false)
    var layer := CanvasLayer.new()
    layer.layer = 50
    add_child(layer)
    var dim := ColorRect.new()
    dim.color = Color(0.01,0.03,0.08,0.72)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(dim)

    var panel := ColorRect.new()
    panel.position = Vector2(270, 205)
    panel.size = Vector2(740, 310)
    panel.color = Color("#13243b")
    layer.add_child(panel)

    var title := Label.new()
    title.text = title_text
    title.position = Vector2(330, 250)
    title.size = Vector2(620, 70)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 42)
    title.add_theme_color_override("font_color", Color("#ffd85e") if won else Color("#ff6f73"))
    layer.add_child(title)

    var label := Label.new()
    label.text = detail
    label.position = Vector2(330, 335)
    label.size = Vector2(620, 50)
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.add_theme_font_size_override("font_size", 20)
    label.add_theme_color_override("font_color", Color.WHITE)
    layer.add_child(label)

    var replay := _make_ui_button("TEKRAR OYNA", Vector2(385, 420), Vector2(230, 68), 22)
    replay.pressed.connect(_start_game)
    layer.add_child(replay)
    var menu := _make_ui_button("MENÜ", Vector2(665, 420), Vector2(230, 68), 22)
    menu.pressed.connect(_show_menu)
    layer.add_child(menu)
