extends CharacterBody2D

signal health_changed(value: int)
signal died

const SPEED := 300.0
const JUMP_VELOCITY := -650.0
const GRAVITY := 1700.0

var health := 3
var touch_left := false
var touch_right := false
var jump_buffer := 0.0
var invulnerable := 0.0
var respawn_position := Vector2.ZERO
var facing := 1.0
var sprite: AnimatedSprite2D
var jump_key_was_down := false

func _ready() -> void:
    add_to_group("player")
    collision_layer = 2
    collision_mask = 1 | 4
    var shape := RectangleShape2D.new()
    shape.size = Vector2(46, 78)
    var collision := CollisionShape2D.new()
    collision.shape = shape
    add_child(collision)

    sprite = AnimatedSprite2D.new()
    var sf := SpriteFrames.new()
    sf.add_animation("idle")
    sf.set_animation_loop("idle", true)
    sf.set_animation_speed("idle", 3.0)
    sf.add_frame("idle", load("res://assets/prince/run_0.png"))
    sf.add_animation("run")
    sf.set_animation_loop("run", true)
    sf.set_animation_speed("run", 11.0)
    for i in range(8):
        sf.add_frame("run", load("res://assets/prince/run_%d.png" % i))
    sf.add_animation("jump")
    sf.set_animation_loop("jump", true)
    sf.add_frame("jump", load("res://assets/prince/run_2.png"))
    sprite.sprite_frames = sf
    sprite.animation = "idle"
    sprite.scale = Vector2(0.42, 0.42)
    sprite.position = Vector2(0, -18)
    add_child(sprite)

func set_touch_left(value: bool) -> void:
    touch_left = value

func set_touch_right(value: bool) -> void:
    touch_right = value

func request_jump() -> void:
    jump_buffer = 0.16

func _physics_process(delta: float) -> void:
    if invulnerable > 0.0:
        invulnerable -= delta
        modulate.a = 0.48 if int(invulnerable * 12.0) % 2 == 0 else 1.0
    else:
        modulate.a = 1.0

    var jump_key_down := Input.is_key_pressed(KEY_SPACE) or Input.is_key_pressed(KEY_UP)
    if jump_key_down and not jump_key_was_down:
        request_jump()
    jump_key_was_down = jump_key_down
    jump_buffer = maxf(0.0, jump_buffer - delta)

    var input_dir := 0.0
    if touch_left or Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
        input_dir -= 1.0
    if touch_right or Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
        input_dir += 1.0

    if input_dir != 0.0:
        facing = signf(input_dir)
        velocity.x = move_toward(velocity.x, input_dir * SPEED, 1800.0 * delta)
    else:
        velocity.x = move_toward(velocity.x, 0.0, 2200.0 * delta)

    if not is_on_floor():
        velocity.y += GRAVITY * delta
    elif jump_buffer > 0.0:
        velocity.y = JUMP_VELOCITY
        jump_buffer = 0.0

    var pre_vy := velocity.y
    move_and_slide()

    for i in range(get_slide_collision_count()):
        var collision := get_slide_collision(i)
        var other = collision.get_collider()
        if other != null and other.is_in_group("enemy"):
            if pre_vy > 100.0 and global_position.y < other.global_position.y - 18.0:
                if other.has_method("defeat"):
                    other.defeat()
                velocity.y = JUMP_VELOCITY * 0.52
            else:
                take_damage()

    if global_position.y > 900.0:
        hazard_hit()

    sprite.flip_h = facing < 0.0
    if not is_on_floor():
        sprite.play("jump")
    elif absf(velocity.x) > 35.0:
        sprite.play("run")
    else:
        sprite.play("idle")

func take_damage() -> void:
    if invulnerable > 0.0:
        return
    health -= 1
    health_changed.emit(health)
    if health <= 0:
        died.emit()
        return
    invulnerable = 1.2
    velocity = Vector2(-facing * 210.0, -300.0)

func hazard_hit() -> void:
    if invulnerable > 0.0:
        return
    take_damage()
    if health > 0:
        global_position = respawn_position
        velocity = Vector2.ZERO
