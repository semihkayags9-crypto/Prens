extends CharacterBody2D

var enemy_type := "slime"
var left_bound := 0.0
var right_bound := 0.0
var direction := -1.0
var speed := 78.0
var gravity := 1700.0
var defeated := false
var visual: Sprite2D
var bob_time := 0.0

const TEX := {
    "slime": preload("res://assets/enemies/slime.svg"),
    "mushroom": preload("res://assets/enemies/mushroom.svg"),
    "goblin": preload("res://assets/enemies/goblin.svg"),
    "beetle": preload("res://assets/enemies/beetle.svg")
}

func setup(new_type: String, left_x: float, right_x: float) -> void:
    enemy_type = new_type
    left_bound = left_x
    right_bound = right_x
    collision_layer = 4
    collision_mask = 1 | 2
    add_to_group("enemy")

    var shape := CapsuleShape2D.new()
    if enemy_type == "beetle":
        shape.radius = 24.0
        shape.height = 44.0
    elif enemy_type == "slime":
        shape.radius = 22.0
        shape.height = 42.0
    else:
        shape.radius = 22.0
        shape.height = 58.0

    var collision := CollisionShape2D.new()
    collision.shape = shape
    collision.position.y = -4
    add_child(collision)

    visual = Sprite2D.new()
    visual.texture = TEX.get(enemy_type, TEX["slime"])
    visual.scale = Vector2(0.62, 0.62)
    visual.position = Vector2(0, -22)
    add_child(visual)

    speed = {"slime": 62.0, "mushroom": 72.0, "goblin": 90.0, "beetle": 105.0}.get(enemy_type, 75.0)

func _physics_process(delta: float) -> void:
    if defeated:
        return
    bob_time += delta
    if visual:
        visual.position.y = -22.0 + sin(bob_time * 4.0) * 2.0
        visual.flip_h = direction > 0.0
        visual.rotation = sin(bob_time * 3.0) * 0.025

    if not is_on_floor():
        velocity.y += gravity * delta
    velocity.x = direction * speed
    move_and_slide()

    if global_position.x <= left_bound:
        direction = 1.0
    elif global_position.x >= right_bound:
        direction = -1.0
    if is_on_wall():
        direction *= -1.0

func defeat() -> void:
    if defeated:
        return
    defeated = true
    collision_layer = 0
    collision_mask = 0
    var tween := create_tween()
    tween.set_parallel(false)
    tween.tween_property(self, "scale", Vector2(1.15, 0.32), 0.10)
    tween.tween_property(self, "modulate:a", 0.0, 0.18)
    tween.tween_callback(queue_free)
