extends Area2D

signal picked(kind: String, amount: int)

var kind := "gem"
var amount := 1
var base_y := 0.0
var phase := 0.0

func setup(new_kind: String, new_amount: int = 1) -> void:
    kind = new_kind
    amount = new_amount
    collision_layer = 8
    collision_mask = 2
    var shape := CircleShape2D.new()
    shape.radius = 22.0
    var collision := CollisionShape2D.new()
    collision.shape = shape
    add_child(collision)
    body_entered.connect(_on_body_entered)
    phase = randf() * TAU
    base_y = position.y
    queue_redraw()

func _process(delta: float) -> void:
    phase += delta * 2.2
    position.y = base_y + sin(phase) * 5.0
    rotation = sin(phase * 0.6) * 0.05

func _on_body_entered(body: Node) -> void:
    if body.is_in_group("player"):
        picked.emit(kind, amount)
        queue_free()

func _draw() -> void:
    if kind == "coin":
        draw_circle(Vector2.ZERO, 20, Color("#ffca28"))
        draw_circle(Vector2.ZERO, 15, Color("#ffea70"))
        draw_circle(Vector2.ZERO, 8, Color("#e09a00"))
    else:
        var pts := PackedVector2Array([Vector2(0,-25), Vector2(20,-5), Vector2(13,21), Vector2(0,29), Vector2(-13,21), Vector2(-20,-5)])
        draw_colored_polygon(pts, Color("#b73cff"))
        draw_polyline(PackedVector2Array([pts[0],pts[1],pts[2],pts[3],pts[4],pts[5],pts[0]]), Color("#f1b5ff"), 3.0)
        draw_line(Vector2(0,-23), Vector2(0,26), Color(1,1,1,0.45), 2.0)
