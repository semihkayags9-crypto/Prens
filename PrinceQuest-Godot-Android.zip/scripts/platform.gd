extends StaticBody2D

var platform_size := Vector2(320, 70)

func setup(new_size: Vector2) -> void:
    platform_size = new_size
    collision_layer = 1
    collision_mask = 0
    var shape := RectangleShape2D.new()
    shape.size = platform_size
    var collision := CollisionShape2D.new()
    collision.shape = shape
    add_child(collision)
    queue_redraw()

func _draw() -> void:
    var rect := Rect2(-platform_size * 0.5, platform_size)
    draw_rect(rect, Color("#8a4f2a"))
    draw_rect(Rect2(rect.position, Vector2(platform_size.x, 20)), Color("#51b84b"))
    draw_rect(Rect2(rect.position + Vector2(0, 14), Vector2(platform_size.x, 10)), Color("#2f8f3b"))

    var x := rect.position.x + 14.0
    while x < rect.end.x - 10.0:
        draw_circle(Vector2(x, rect.position.y + 6), 6.0, Color("#7cdb5e"))
        x += 28.0

    var y := rect.position.y + 42.0
    while y < rect.end.y - 8.0:
        var xx := rect.position.x + 26.0 + fmod(y, 43.0)
        while xx < rect.end.x - 15.0:
            draw_circle(Vector2(xx, y), 4.0, Color("#6c3b23"))
            xx += 48.0
        y += 32.0
