extends StaticBody2D

var platform_size := Vector2(320, 70)
var grass_color := Color("#67c943")
var dirt_color := Color("#8b4f2b")

func setup(new_size: Vector2) -> void:
    platform_size = new_size
    collision_layer = 1
    collision_mask = 0
    var shape := RectangleShape2D.new()
    shape.size = platform_size
    var collision := CollisionShape2D.new()
    collision.shape = shape
    add_child(collision)
    queue_redraw()

func _draw() -> void:
    var rect := Rect2(-platform_size * 0.5, platform_size)
    draw_rect(rect, dirt_color)
    draw_rect(Rect2(rect.position, Vector2(platform_size.x, 16)), grass_color)
    draw_line(Vector2(rect.position.x, rect.position.y + 16), Vector2(rect.end.x, rect.position.y + 16), Color("#3e8e2e"), 4.0)
    var x := rect.position.x + 18.0
    while x < rect.end.x - 12.0:
        draw_circle(Vector2(x, rect.position.y + 8), 5.0, Color("#8fe05b"))
        x += 32.0
