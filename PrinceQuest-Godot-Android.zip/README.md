# Prince Quest v0.4 — Route + Joystick + Visual Upgrade

Godot 4 tabanlı yatay Android platform oyunu.

## v0.4 düzeltmeleri
- Sol/sağ butonları kaldırıldı, analog yatay joystick eklendi.
- Zıplama butonu 228x228 px yapıldı.
- Oyuncu zıplaması -900 / gravity 1850 olarak yeniden dengelendi.
- Ana rota baştan kuruldu. Zemin boşlukları 80-115 px aralığında.
- Alçak tavan sorunu giderildi: üst platformların altındaki açıklık yaklaşık 117-167 px.
- Üst platformlar one-way yapıldı; aşağıdan geçilebilir, üstten basılabilir.
- Üst platformlara çıkış yüksekliği oyuncunun zıplama zirvesinin altında tutuldu.
- Platform görselleri detaylı SVG tile setine geçirildi.
- Arka plan, kale, koleksiyonlar ve dört düşman görseli yenilendi.
- Kamera takibi, 1280x720 landscape ve Android ETC2/ASTC ayarları korunuyor.

## Kontroller
- Android: sol altta analog joystick, sağ altta zıplama.
- PC: A/D veya ok tuşları, Space/Up ile zıpla.

## APK
ZIP'in adı `PrinceQuest-Godot-Android.zip` olarak tutuldu. Mevcut GitHub Actions akışın bu adı arıyorsa değiştirmene gerek yok.
