extends Control

signal axis_changed(value: float)

var active_touch := -1
var dragging_mouse := false
var knob_offset := Vector2.ZERO
var axis_value := 0.0
const BASE_RADIUS := 86.0
const KNOB_RADIUS := 42.0
const DEADZONE := 0.12

func _ready() -> void:
    custom_minimum_size = Vector2(230, 230)
    mouse_filter = Control.MOUSE_FILTER_STOP
    queue_redraw()

func _gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and active_touch == -1:
            active_touch = event.index
            _set_from_point(event.position)
            accept_event()
        elif not event.pressed and event.index == active_touch:
            active_touch = -1
            _reset_stick()
            accept_event()
    elif event is InputEventScreenDrag and event.index == active_touch:
        _set_from_point(event.position)
        accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        dragging_mouse = event.pressed
        if dragging_mouse:
            _set_from_point(event.position)
        else:
            _reset_stick()
        accept_event()
    elif event is InputEventMouseMotion and dragging_mouse:
        _set_from_point(event.position)
        accept_event()

func _set_from_point(point: Vector2) -> void:
    var center := size * 0.5
    var offset := point - center
    if offset.length() > BASE_RADIUS:
        offset = offset.normalized() * BASE_RADIUS
    knob_offset = offset
    var raw := clampf(offset.x / BASE_RADIUS, -1.0, 1.0)
    if absf(raw) < DEADZONE:
        raw = 0.0
    axis_value = raw
    axis_changed.emit(axis_value)
    queue_redraw()

func _reset_stick() -> void:
    knob_offset = Vector2.ZERO
    axis_value = 0.0
    axis_changed.emit(0.0)
    queue_redraw()

func _draw() -> void:
    var c := size * 0.5
    # soft outer shadow
    draw_circle(c + Vector2(0, 8), BASE_RADIUS + 10, Color(0.0, 0.0, 0.0, 0.20))
    draw_circle(c, BASE_RADIUS + 7, Color(0.92, 0.97, 1.0, 0.27))
    draw_circle(c, BASE_RADIUS, Color(0.025, 0.09, 0.16, 0.70))
    draw_arc(c, BASE_RADIUS - 3, 0, TAU, 72, Color(0.83, 0.94, 1.0, 0.88), 4.0)
    draw_circle(c, BASE_RADIUS * 0.54, Color(0.12, 0.36, 0.55, 0.18))

    var k := c + knob_offset
    draw_circle(k + Vector2(0, 5), KNOB_RADIUS + 5, Color(0, 0, 0, 0.22))
    draw_circle(k, KNOB_RADIUS + 3, Color(0.92, 0.97, 1.0, 0.88))
    draw_circle(k, KNOB_RADIUS, Color(0.08, 0.28, 0.45, 0.96))
    draw_circle(k - Vector2(9, 10), KNOB_RADIUS * 0.34, Color(0.60, 0.86, 1.0, 0.28))
