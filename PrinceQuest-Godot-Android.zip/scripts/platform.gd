extends StaticBody2D

var platform_size := Vector2(320, 70)
var one_way := false
const GROUND_TEX = preload("res://assets/tiles/platform_ground.svg")
const LEDGE_TEX = preload("res://assets/tiles/platform_ledge.svg")

func setup(new_size: Vector2, is_one_way: bool = false) -> void:
    platform_size = new_size
    one_way = is_one_way
    collision_layer = 1
    collision_mask = 0

    var shape := RectangleShape2D.new()
    shape.size = platform_size
    var collision := CollisionShape2D.new()
    collision.shape = shape
    collision.one_way_collision = one_way
    collision.one_way_collision_margin = 10.0
    add_child(collision)

    var shadow := Polygon2D.new()
    shadow.polygon = PackedVector2Array([
        Vector2(-platform_size.x * 0.48, -platform_size.y * 0.40),
        Vector2(platform_size.x * 0.50, -platform_size.y * 0.40),
        Vector2(platform_size.x * 0.50, platform_size.y * 0.52),
        Vector2(-platform_size.x * 0.48, platform_size.y * 0.52)
    ])
    shadow.position = Vector2(8, 10)
    shadow.color = Color(0.04, 0.06, 0.08, 0.18)
    add_child(shadow)

    var sprite := Sprite2D.new()
    sprite.texture = LEDGE_TEX if one_way else GROUND_TEX
    var base_size := Vector2(384.0, 96.0) if one_way else Vector2(512.0, 128.0)
    sprite.scale = platform_size / base_size
    add_child(sprite)
