extends CharacterBody2D

var enemy_type := "slime"
var left_bound := 0.0
var right_bound := 0.0
var direction := -1.0
var speed := 72.0
var gravity := 1600.0
var defeated := false

func setup(new_type: String, left_x: float, right_x: float) -> void:
    enemy_type = new_type
    left_bound = left_x
    right_bound = right_x
    collision_layer = 4
    collision_mask = 1 | 2
    add_to_group("enemy")
    var shape := RectangleShape2D.new()
    shape.size = Vector2(52, 46) if enemy_type == "slime" else Vector2(48, 64)
    var collision := CollisionShape2D.new()
    collision.shape = shape
    collision.position.y = -4
    add_child(collision)
    queue_redraw()

func _physics_process(delta: float) -> void:
    if defeated:
        return
    if not is_on_floor():
        velocity.y += gravity * delta
    velocity.x = direction * speed
    move_and_slide()
    if global_position.x <= left_bound:
        direction = 1.0
    elif global_position.x >= right_bound:
        direction = -1.0
    if is_on_wall():
        direction *= -1.0

func defeat() -> void:
    if defeated:
        return
    defeated = true
    collision_layer = 0
    collision_mask = 0
    var tween := create_tween()
    tween.tween_property(self, "scale", Vector2(1.25, 0.2), 0.12)
    tween.tween_property(self, "modulate:a", 0.0, 0.16)
    tween.tween_callback(queue_free)

func _draw() -> void:
    if enemy_type == "slime":
        draw_circle(Vector2(0,-8), 30, Color("#28c9f4"))
        draw_circle(Vector2(-10,-14), 5, Color.WHITE)
        draw_circle(Vector2(10,-14), 5, Color.WHITE)
        draw_circle(Vector2(-9,-14), 2.2, Color("#18354f"))
        draw_circle(Vector2(9,-14), 2.2, Color("#18354f"))
        draw_arc(Vector2(0,-3), 11, 0.25, PI-0.25, 16, Color("#174a67"), 2.4)
    else:
        draw_circle(Vector2(0,-25), 23, Color("#71c84a"))
        draw_colored_polygon(PackedVector2Array([Vector2(-20,-32),Vector2(-38,-24),Vector2(-20,-16)]), Color("#71c84a"))
        draw_colored_polygon(PackedVector2Array([Vector2(20,-32),Vector2(38,-24),Vector2(20,-16)]), Color("#71c84a"))
        draw_rect(Rect2(-18,-3,36,30), Color("#8a5a34"))
        draw_circle(Vector2(-8,-29), 4, Color.WHITE)
        draw_circle(Vector2(8,-29), 4, Color.WHITE)
        draw_circle(Vector2(-7,-29), 1.8, Color("#1c3320"))
        draw_circle(Vector2(7,-29), 1.8, Color("#1c3320"))
        draw_arc(Vector2(0,-19), 9, 0.2, PI-0.2, 12, Color("#29552c"), 2.0)
        draw_line(Vector2(21,-3), Vector2(34,-32), Color("#6b482d"), 7.0)
