# Prince Quest 👑💎

Godot 4 tabanlı, Android için hazırlanmış oynanabilir 2D platform prototipi.

## Bu sürümde ne var?

- Prens karakteri sağa/sola hareket eder.
- Koşarken 8 karelik animasyonda **eller ve bacaklar hareket eder**.
- Mobil ekranda sol altta `◀` ve `▶` hareket tuşları vardır.
- Sağ altta `▲` zıplama tuşu vardır.
- Klavyede A/D veya yön tuşları ve Space ile de oynanabilir.
- Altın ve mor elmas toplama sistemi.
- 3 can sistemi.
- Sevimli slime ve goblin düşmanları.
- Düşmanın üstüne zıplayınca düşman yenilir.
- Dikenli engeller ve boşluklar.
- Bölüm sonunda kalede prenses hedefi.
- Başlangıç ekranında hazırladığımız konsept görsel kullanılır.
- Android APK ve Web export presetleri dahildir.

## Godot ile çalıştırma

1. Godot 4.3 veya daha yeni bir Godot 4.x sürümünü aç.
2. `project.godot` dosyasını içe aktar.
3. `F6/F5` ile çalıştır.

## Android APK alma

Godot içinde Android export şablonları ve Android SDK kuruluysa:

`Project > Export > Android > Export Project`

çıktı yolu varsayılan olarak:

`build/PrinceQuest.apk`

## GitHub Actions ile APK

Repo GitHub'a yüklendiğinde `.github/workflows/build-apk.yml` çalışacak şekilde hazırlanmıştır.

- GitHub repo sayfasında **Actions** sekmesine gir.
- `Build Android APK` workflow'unu seç.
- Gerekirse `Run workflow` ile elle başlat.
- İşlem başarılı olursa `PrinceQuest-Android` adlı artifact içinden APK'yı indir.

> Not: GitHub runner / Godot Android export imajı tarafında sürüm değişiklikleri olursa workflow şu anda `barichello/godot-ci:4.7.1` ile ayarlı. Projenin kendisi Godot 4.x içindir.

## Proje yapısı

```text
assets/
  prince/                 # 8 kare prens koşu animasyonu
  reference/              # konsept görseller
scenes/
  Main.tscn
scripts/
  main.gd
  player.gd
  enemy.gd
  collectible.gd
  platform.gd
  hazard.gd
  goal.gd
  background.gd
.github/workflows/
  build-apk.yml
export_presets.cfg
project.godot
```

## İlk prototip hedefi

Bu proje tek bölümlük oynanabilir iskelet olarak tasarlandı. Sonraki aşamalarda ayrı sprite setleri, sesler, bölüm seçimi, boss, kayıt sistemi ve daha zengin animasyonlar eklenebilir.
